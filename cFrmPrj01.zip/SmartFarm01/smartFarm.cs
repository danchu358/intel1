﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SmartFarm01
{
    public partial class mainWin : Form
    {
        string Conn = "Server=localhost;Database=smartfarm_table;Uid=root;Pwd=123456;";

        public mainWin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Port_Combox.Text == "")
            {
                MessageBox.Show("포트를 선택하세요");
            }
            else
            {
                serialPort1.PortName = Port_Combox.Text;
                if (serialPort1.IsOpen == false)
                {
                    serialPort1.Open();
                }
            }
        }

        private void Close_btn_Click_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen == true)
            {
                serialPort1.Close();
            }
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            string illdata = serialPort1.ReadLine();
            string date = DateTime.Now.ToString();

            this.Invoke((MethodInvoker)delegate
            {
                tpLabel.Text = "온도 데이터 : " + illdata;
                huLabel.Text = "습도 데이터 : " + illdata;
            });

            using (MySqlConnection conn = new MySqlConnection(Conn))
            {
                conn.Open();
                MySqlCommand msc = new MySqlCommand(
                    "insert into sensor(illuminance, date) values(" + illdata + ", '" + date + "')"
                    , conn);
                msc.ExecuteNonQuery();
            }
        }
    }
}
